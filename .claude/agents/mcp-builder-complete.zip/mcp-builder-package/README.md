# MCP Builder Skill

A comprehensive skill for building high-quality MCP (Model Context Protocol) servers.

## Installation

This package is ready to be added to your GitHub repository at:
`https://github.com/majidraza1228/agentic-dev-template`

### Add to Your Repository

1. Extract this zip file
2. Copy the `.claude` folder to your repository root:
   ```bash
   cp -r .claude /path/to/agentic-dev-template/
   ```

3. Commit and push:
   ```bash
   cd /path/to/agentic-dev-template
   git add .claude/agents/mcp-builder/
   git commit -m "Add MCP builder skill for creating high-quality MCP servers"
   git push origin main
   ```

### For Users to Install from Your Repo

Once pushed to GitHub, others can install with:

```bash
# Clone your repo
git clone https://github.com/majidraza1228/agentic-dev-template.git

# Copy to their Claude skills directory
mkdir -p ~/.claude/skills/examples/
cp -r agentic-dev-template/.claude/agents/mcp-builder ~/.claude/skills/examples/
```

Or one-liner:
```bash
git clone https://github.com/majidraza1228/agentic-dev-template.git && \
mkdir -p ~/.claude/skills/examples/ && \
cp -r agentic-dev-template/.claude/agents/mcp-builder ~/.claude/skills/examples/ && \
echo "✅ MCP Builder skill installed!"
```

## What's Included

- **SKILL.md**: Main skill guide with 4-phase development process
- **LICENSE.txt**: License information
- **reference/**: Detailed implementation guides
  - `evaluation.md`: Evaluation creation guide (22KB)
  - `mcp_best_practices.md`: MCP best practices (7KB)
  - `node_mcp_server.md`: TypeScript implementation guide (28KB)
  - `python_mcp_server.md`: Python implementation guide (25KB)
- **scripts/**: Evaluation tools
  - `connections.py`: Connection utilities
  - `evaluation.py`: Evaluation runner
  - `example_evaluation.xml`: Example evaluation
  - `requirements.txt`: Python dependencies

## Directory Structure

```
.claude/agents/mcp-builder/
├── SKILL.md                          # Main skill file (9KB)
├── LICENSE.txt                       # License information (11KB)
├── reference/                        # Reference documentation (82KB)
│   ├── evaluation.md                 # Evaluation creation guide
│   ├── mcp_best_practices.md         # MCP best practices
│   ├── node_mcp_server.md            # TypeScript implementation guide
│   └── python_mcp_server.md          # Python implementation guide
└── scripts/                          # Evaluation scripts (20KB)
    ├── connections.py                # Connection utilities
    ├── evaluation.py                 # Evaluation runner
    ├── example_evaluation.xml        # Example evaluation
    └── requirements.txt              # Python dependencies
```

**Total Size**: ~122KB

## Usage

Once installed, Claude will automatically use this skill when you:
- Ask to "build an MCP server"
- Request help with "MCP development"
- Want to "create MCP tools"
- Need to "design an MCP server architecture"

### Example Prompts

```
"Help me build an MCP server for the GitHub API"
"Create an MCP server in TypeScript for Notion"
"Build me a Python MCP server for the Jira API"
"Create evaluations for my MCP server"
```

## Features

✅ **4-Phase Development Process**: Research → Implementation → Testing → Evaluation  
✅ **TypeScript & Python Support**: Complete guides for both languages  
✅ **Best Practices**: Production-tested patterns and conventions  
✅ **Evaluation Framework**: Systematic MCP server quality testing  
✅ **Working Examples**: Real code you can adapt  
✅ **Quality Checklists**: Ensure high-quality implementations  

## License

See LICENSE.txt for complete terms.

## Repository

🔗 https://github.com/majidraza1228/agentic-dev-template  
📂 Skill location: `.claude/agents/mcp-builder/`

---

**Ready to build amazing MCP servers!** 🚀
